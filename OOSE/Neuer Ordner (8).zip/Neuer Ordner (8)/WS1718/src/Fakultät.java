
public class Fakult�t extends Dialogue{
	Fakult�t(){
		super(x->{
		int i = Integer.valueOf(x);	
	int result = 1;
	while(i>=1) {
		result=result*i;
		i--;
	}
	return""+result;
		
		
		
		
		});
	
	}

}
