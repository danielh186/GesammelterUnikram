
public class Raum {
String raumnummer;
int platz;

Raum(String r, int p) {
	raumnummer = r;
	platz = p;
}

@Override
public boolean equals(Object o) {
	if(!(o instanceof Raum)) {
		return false;
	}
	var that = (Raum) o;
	return this.raumnummer.equals(that.raumnummer) && this.platz == that.platz;	
}

@Override
public String toString() {
	return raumnummer+" "+platz;	
}











}
