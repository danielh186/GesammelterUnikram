import javax.swing.*;

public class FactorialGUI extends SimpleGUI {
	
	FactorialGUI(){
		button.addActionListener(x->
		output.setText(""+factorial(Integer.valueOf(input.getText())))
				);
	}
	public static int factorial(int j) {
		if(j<=1) {
			return 1;
		}
		return j*factorial(j-1);
	}
	
	
	public static void main(String[]args) {
		JFrame frame = new JFrame();
		var a = new FactorialGUI();
		frame.add(a);
		a.setVisible(true);
		frame.setVisible(true);
		frame.pack();
		
		
		
		
		
		
	}

}
