import javax.swing.*;

public class GeneralGUI extends SimpleGUI {
	GeneralGUI(StringLogik s){
		button.addActionListener(x->output.setText(s.apply(input.getText())));
		
	}
	
	
	public static void main(String[] args) {
		var frame = new JFrame();
		var b = new GeneralGUI(x->Integer.valueOf(x)*Integer.valueOf(x)+"");
		frame.add(b);
		b.setVisible(true);
		frame.setVisible(true);
		frame.pack();
		
		
	}

}
