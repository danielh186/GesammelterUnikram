
public interface Property <A>{
	boolean test (A al);

}
