
public class Li<A> {
	private int size = 0;
	private A[] array = (A[]) new Object[10];

	public void add(A el) {
		if (size >= array.length) {
			enlargeArray();
		}
		array[size++] = el;
	}

	private void enlargeArray() {
		A[] newarray = (A[]) new Object[array.length + 10];
		for (int i = 0; i < array.length; i++)
			newarray[i] = array[i];
		array = newarray;
	}

	public A get(int i) {
		return array[i];
	}

	public int size() {
		return size;
	}

	public boolean isEmpty() {
		return size == 0;
	}
	boolean contains(A o) {
		for(int i = 0; i<size; i++) {
			if(this.get(i).equals(o)) {
				return true;
			}
		}
		return false;
	}
	public boolean containsAll(Li<A> o) {
		if(o.isEmpty()) {
			return false;
		}
		for(int i = 0; i<o.size(); i++) {
			if(!(this.contains(o.get(i)))) {
				return false;
			}
		}
		return true;
}
	public boolean isSorted(Comp<A> comp) {
		for(int i = 0; i<size-1;i++) {
			if(!comp.isSmaller(get(i), get(i+1)))
			return false;
		}
		return true;
	}
	
	
	
	
	
	
}