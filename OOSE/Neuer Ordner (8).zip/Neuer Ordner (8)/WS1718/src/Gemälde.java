enum kat{
	�l, radierung, aquarell, zeichnung
}
public class Gem�lde extends Kunstwerk{
	int h�he;
	int breite;
	kat kat;
	
	Gem�lde(String n, int w, String t, int h, int b, kat kat){
		super(n, w ,t);
		h�he=h;
		breite=b;
		this.kat=kat;
		
	}
}
