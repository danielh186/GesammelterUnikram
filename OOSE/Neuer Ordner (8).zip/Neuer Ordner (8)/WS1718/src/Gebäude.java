import java.util.List;

public class Geb�ude{
List<Raum> Raumliste;

public Geb�ude(List<Raum> r){
this.Raumliste = r;
}

int wievielPlatz(String raumnummer){
	for (int i = 0; i < Raumliste.size(); i++) {
		if(Raumliste.get(i).raumnummer.equals(raumnummer)) {
			return Raumliste.get(i).platz;
			
		}
		
	}
	return -1;
	
}
}


