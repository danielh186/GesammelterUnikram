enum bs{
	Unix, Linux, Windows, MacOS
}
public class Rechnerraum extends Raum{
	bs bs;
	Rechnerraum(String r,int p , bs bs){
		super(r, p);
		this.bs=bs;
	}
	
	@Override
	public String toString() {
		return raumnummer+" "+platz+" "+bs;
		
	}
	
	
	
	

}
