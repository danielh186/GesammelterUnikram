
interface StringLogik {
	String apply (String s);
}
