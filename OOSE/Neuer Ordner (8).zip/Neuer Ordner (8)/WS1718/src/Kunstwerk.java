
public class Kunstwerk {
String name;
int wert;
String titel;

Kunstwerk(String n, int w, String t){
	name=n;
	wert=w;
	titel=t;
	

}
Kunstwerk(String n, String t){
	this(n, 42, t);
}
@Override
public boolean equals(Object o){
	if(!(o instanceof Kunstwerk)) return false;
	var that = (Kunstwerk) o;
	return this.name.equals(that.name) && this.wert == that.wert && this.titel.equals(that.titel); 
	
}





}
