
public interface ButtonLogic {
	String eval(String str);
	

}
