
public class AL<A> {
    private int size = 0;
    private A[] array = (A[]) new Object[10];

    public void add(A el) {
        if (size >= array.length) {
            enlargeArray();
        }
        array[size++] = el;
    }

    private void enlargeArray() {
        A[] newarray = (A[]) new Object[array.length + 10];
        for (int i = 0; i < array.length; i++)
            newarray[i] = array[i];
        array = newarray;
    }

    public A get(int i) {
        return array[i];
    }

    public int size() {
        return size;
    }

    public boolean isEmpty() {
        return size == 0;
    }
    
    boolean startsWith(AL<A> that) {
    	if(this.size<that.size) {
    		return false;
    	}
    	for(int i = 0; i < that.size(); i++) {
    		if(!this.get(i).equals(that.get(i))) {
    			return false;	
    		}
    		
    		
    	}
    	return true;
    	
    	
    	
    }
    boolean all(Property<A> p) {
    	if(this.size==0) {
    		return false;
    	}
    	for(int i =0; i<this.size; i++) {
    		if(!p.test(get(i))){
    			return false;
    		}
    	}
    	return true;
    }
    
    
    AL<A> filter(Property<A> p){
    var result = new AL<A>();
    for(int i =0; i<this.size; i++) {
    	if(p.test(get(i))) {
    		result.add(this.get(i));	
    	}
    }
    return result;
    }
    
    public boolean isSorted(Comp<A> comp) {
    	for(int i = 0; i<this.size-1; i++) {
    		if(!comp.isSmaller(this.get(i), this.get(i+1))) {
    			return false;
    		}
    		
    	}
    	return true;
    }
    
    
    
    
    
    
    
    
    
    
    
}
