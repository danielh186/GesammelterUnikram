
public interface Comp<A> {
boolean isSmaller(A a1, A a2);
}
