
	import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextField ;
import javafx.scene.layout.BorderPane ;
import javafx.stage.Stage ;

public class Dialogue extends Application {
    ButtonLogic logic;
    public Dialogue(ButtonLogic logic) {
        this.logic = logic;
    }

    @Override
    public void start(Stage primaryStage) {
        Button btn = new Button();
        TextField out = new TextField();
        TextField in = new TextField();
        out.setEditable(false);
        btn.setText("Dr�cken");
        btn.setOnAction((event) -> {
            out.setText(logic.eval(in.getText()));
        });
        BorderPane root = new BorderPane();
        root.setTop(in);
        root.setCenter(btn);
        root.setBottom(out);
        primaryStage.setScene(new Scene(root));
        primaryStage.show();
    }


}
	
	


