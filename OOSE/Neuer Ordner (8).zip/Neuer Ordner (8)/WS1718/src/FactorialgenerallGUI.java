
public class FactorialgenerallGUI extends GeneralGUI{
	FactorialgenerallGUI(){
		super(x->{
			int i = Integer.valueOf(x);
			var result = 1;
			while(i>= 1) {
			result=result*i;
			i--;
			}
			return ""+result;
		});
		
	}

}
