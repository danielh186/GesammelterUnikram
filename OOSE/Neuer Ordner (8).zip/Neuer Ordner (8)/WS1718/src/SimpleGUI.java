import javax.swing.*;
class SimpleGUI extends JPanel{
	JTextField input = new JTextField();
	JLabel output = new JLabel();
	JButton button = new JButton("Dr�cken");
	SimpleGUI(){
		this.add(input);
		this.add(button);
		this.add(output);
	}
	

}
