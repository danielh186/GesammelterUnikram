
public class Versteigerung extends java.util.ArrayList<Kunstwerk>{
	long gesamtWert() {
		long result = 0;
		for(int i = 0; i<this.size(); i++) {
			result = result + get(i).wert;
		}
		return result;
	}
	
	
	Kunstwerk teuerstesKunstwerk() {
		Kunstwerk result = get(0);
		for(int i = 0; i<this.size(); i++) {
			if(result.wert<get(i).wert) {
				result=get(i);
			}
		}
		return result;
	}
	
	
	
	
	
	
	
}

